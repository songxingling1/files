#include <bits/stdc++.h>
#define int long long
namespace SXL {
	using std::string;
	using std::cin;
	constexpr int MOD = 1e9;
	int dp[305][305];
	void main() {
		string a;
		cin >> a;
		int len = a.size();
		if(len % 2 == 0) {
			printf("0\n");
			return
			;
		}
		a = " " + a;
		for(int i = 1;i <= len;i++) {
			dp[i][i] = 1;
		}
		for(int i = 2;i <= len;i++)  {
			for(int l = 1;l + i - 1 <= len;l++) {
				int r = l + i - 1;
				if(a[l] == a[r]) {
					for(int z = l;z <= r;z++) {
						if(a[l] == a[z]) {
							dp[l][r] = (dp[l][r] + dp[l][z] * dp[z + 1][r - 1]) % MOD;
						}
					}
				}
			}
		}
		printf("%lld\n",dp[1][len]);
	}
}
signed main() {
	SXL::main();
	return 0;
}
