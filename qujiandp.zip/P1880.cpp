#include <bits/stdc++.h>
#define FOR(I,K,N) for(int I = K;I <= N;I++)
#define REP(I,K,N) for(int I = K;I < N;I++)
using namespace std;
const int MAXN = 1e2 * 2 + 10;
const int INF = 0x3f3f3f3f;
int n,maxa = -INF,mina = INF,len;
int f[MAXN],maxdp[MAXN][MAXN],mindp[MAXN][MAXN],sum[MAXN];
int main() {
#ifdef DEBUG
    freopen("in","r",stdin);
    freopen("out","w",stdout);
#endif // DEBUG
    memset(mindp,127,sizeof(mindp));
    cin >> n;
    len = (n << 1) - 1;
    FOR(i,1,n) {
        cin >> f[i];
        f[i + n] = f[i];
    }
    FOR(i,1,len) {
        sum[i] = sum[i - 1] + f[i];
    }
    FOR(i,1,len) {
        mindp[i][i] = 0;
    }
    FOR(i,2,n) {
        FOR(j,1,len - i + 1) {
            REP(z,j,j + i - 1) {
                maxdp[j][j + i - 1] = max(maxdp[j][j + i - 1],maxdp[j][z] + maxdp[z + 1][j + i - 1] + sum[j + i - 1] - sum[j - 1]);
                mindp[j][j + i - 1] = min(mindp[j][j + i - 1],mindp[j][z] + mindp[z + 1][j + i - 1] + sum[j + i - 1] - sum[j - 1]);
            }
        }
    }
    FOR(i,1,n) {
        maxa = max(maxa,maxdp[i][i + n - 1]);
        mina = min(mina,mindp[i][i + n - 1]);
    }
    cout << mina << endl << maxa << endl;
    return 0;
}
