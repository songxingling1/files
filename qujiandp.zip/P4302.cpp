#include <bits/stdc++.h>
namespace SXL {
	using std::string;
	int dp[105][105];
	void main() {
		string a;
		cin >> a;
		
	}
}
