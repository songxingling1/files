#include <bits/stdc++.h>
namespace SXL {
	using std::max;
	using std::min;
	using std::cin;
	constexpr int MAXN = 200,INF = 0x3f3f3f3f;
	char op[MAXN];
	int num[MAXN];
	int dp[MAXN * 2][MAXN * 2];
	int g[MAXN * 2][MAXN * 2];
	void main() {
		memset(dp,0x80,sizeof(dp));
		memset(g,0x7f,sizeof(g));
		int n;
		cin >> n;
		for(int i = 1;i <= n;i++) {
			cin >> op[i] >> num[i];
			op[i + n] = op[i];
			num[i + n] = num[i];
			dp[i][i] = num[i];
			g[i][i] = num[i];
			dp[i + n][i + n] = num[i];
			g[i + n][i + n] = num[i];
		}
		for(int k = 2;k <= n;k++) {
			for(int l = 1,r = k;r < 2 * n;l++,r++) {
				for(int j = l;j < r;j++) {
					if(op[j + 1] == 't') {
						dp[l][r] = max(dp[l][r],dp[l][j] + dp[j + 1][r]);
						g[l][r] = min(g[l][r],g[l][j] + g[j + 1][r]);
					} else {
						dp[l][r] = max(dp[l][r],
								   max(dp[l][j] * dp[j + 1][r],
								   max(g[l][j] * g[j + 1][r],
								   max(dp[l][j] * g[j + 1][r],
								   	   g[l][j] * dp[j + 1][r]))));
						g[l][r] = min(dp[l][r],
								  min(dp[l][j] * dp[j + 1][r],
								  min(g[l][j] * g[j + 1][r],
								  min(dp[l][j] * g[j + 1][r],
								   	  g[l][j] * dp[j + 1][r]))));
					}
				}
			}
		}
		int ans = -INF;
		for(int i = 1;i <= n;i++) {
			ans = max(ans,dp[i][i + n - 1]);
		}
		printf("%d\n",ans);
		for(int i = 1;i <= n;i++) {
			if(dp[i][i + n - 1] == ans) printf("%d ",i);
		}
		puts("");
	}
}
int main() {
	SXL::main();
	return 0;
}
