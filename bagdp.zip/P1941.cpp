#include <bits/stdc++.h>
namespace SXL {
	using std::min;
	constexpr int MAXN = 10000;
	int x[MAXN + 5],y[MAXN + 5];
	int h[MAXN + 5],l[MAXN + 5],vis[MAXN + 5];
	int dp[MAXN + 5][2005];
	void main() {
		memset(dp,0x3f,sizeof(dp));
		int n,m,k;
		scanf("%d%d%d",&n,&m,&k);
		for(int i = 1;i <= n;i++) {
			scanf("%d%d",x + i,y + i);
			l[i] = 1;
			h[i] = m;
		}
		for(int i = 1,a,b,c;i <= k;i++) {
			scanf("%d%d%d",&a,&b,&c);
			l[a] = b + 1;
			h[a] = c - 1;
			vis[a] = 1;
		}
		for(int i = 1;i <= m;i++) {
			dp[0][i] = 0;
		}
		for(int i = 1;i <= n;i++) {
			for(int j = 1 + x[i];j <= m + x[i];j++) {
				dp[i][j] = min(dp[i - 1][j - x[i]] + 1,dp[i][j - x[i]] + 1);
			}
			for(int j = m + 1;j <= m + x[i];j++) {
				dp[i][m] = min(dp[i][m],dp[i][j]);
			}
			for(int j = 1;j <= m - y[i];j++) {
				dp[i][j] = min(dp[i][j],dp[i - 1][j + y[i]]);
			}
			for(int j = 1;j < l[i];j++) {
				dp[i][j] = dp[0][0];
			}
			for(int j = h[i] + 1;j <= m;j++) {
				dp[i][j] = dp[0][0];
			}
		}
		int ans = dp[0][0];
		for(int i = 1;i <= m;i++) {
			ans = min(dp[n][i],ans);
		}
		if(ans < dp[0][0]) {
			printf("1\n%d\n",ans);
		} else {
			printf("0\n");
			int now,j;
			for(now = n;now >= 1;now--) {
				for(j = 1;j <= m;j++) {
					if(dp[now][j] < dp[0][0]) break;
				}
				if(j < m) break;
			}
			ans = 0;
			for(int i = 1;i <= now;i++) {
				if(vis[i]) ans++;
			}
			printf("%d\n",ans);
		}
	}
}
int main() {
	SXL::main();
	return 0;
}
