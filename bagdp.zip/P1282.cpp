#include <bits/stdc++.h>
namespace SXL {
	using std::min;
	constexpr int MAXN = 1000,pyl = 5000;
	constexpr int tmp = 5000;
	int dp[MAXN + 5][10005];
	int a[MAXN + 5],b[MAXN + 5];
	void main() {
		memset(dp,0x7f,sizeof(dp));
		int n;
		scanf("%d",&n);
		int sum1 = 0,sum2 = 0;
		for(int i = 1;i <= n;i++) {
			scanf("%d%d",a + i,b + i);
			sum1 += a[i];
			sum2 += b[i];
		}
		dp[0][pyl] = 0;
		for(int i = 1;i <= n;i++) {
			for(int j = pyl - tmp;j <= pyl + tmp;j++) {
				dp[i][j] = min(dp[i - 1][j + a[i] - b[i]] + 1,
							   dp[i - 1][j - a[i] + b[i]]);
			}
		}
		int ans = INT_MAX;
		for(int i = 0;i <= tmp;i++) {
			ans = min(dp[n][pyl + i],dp[n][pyl - i]);
			if(ans <= 1000) {
				printf("%d\n",ans);
				break;
			}
		}
	}
};
int main() {
	SXL::main();
	return 0;
}
