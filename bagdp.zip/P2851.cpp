#include <bits/stdc++.h>
#define int long long
namespace SXL {
	using namespace std;
	constexpr int MAXN = 100,MAXM = 1000000;
	constexpr int INF = 0x3f3f3f3f3f3f3f3f,V = 28800;
	int v[MAXN + 5],w[MAXN + 5];
	int dp1[5000005],dp2[5000005];
	void main() {
		memset(dp1,INF,sizeof(dp1));
		memset(dp2,INF,sizeof(dp2));
		int N,T;
		scanf("%lld%lld",&N,&T);
		for(int i = 1;i <= N;i++) {
			scanf("%lld",v + i);
		}
		for(int i = 1;i <= N;i++){
			scanf("%lld",w + i);
		}
		dp1[0] = 0;
		dp2[0] = 0;
		for(int i = 1;i <= N;i++) {
			for(int j = v[i];j <= V;j++) {
				dp1[j] = min(dp1[j],dp1[j - v[i]] + 1);
			}
		}
		for(int i = 1;i <= N;i++) {
			for(int k = 1;k <= w[i];k *= 2) {
				for(int j = V + T;j >= v[i] * k;j--) {
					dp2[j] = min(dp2[j],dp1[j - v[i] * k] + k);
				}
				w[i] -= k;
			}
			if(w[i]) {
				for(int j = V + T;j >= v[i] * w[i];j--) {
					dp2[j] = min(dp2[j],dp1[j - v[i] * w[i]] + w[i]);
				}
			}
		}
		int ans = INF;
		for(int i = T;i <= V + T;i++) {
			ans = min(ans,dp2[i] + dp1[i - T]);
		}
		if(ans == INF) printf("-1\n");
		else printf("%lld\n",ans);
	}
};
signed main() {
	SXL::main();
	return 0;
}
