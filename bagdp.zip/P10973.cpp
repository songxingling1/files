#include <bits/stdc++.h>
namespace SXL {
	using std::deque;
	using ll = long long;
	constexpr int MAXN = 10000005;
	int a[105];
	int v[100005];
	int f[MAXN];
	int n,m;
	int cnt = 0;
	void work() {
		cnt = 0;
		memset(f,0,sizeof(f));
		for(int i = 1;i <= n;i++) {
			scanf("%d",a + i);
		}
		for(int i = 1,b;i <= n;i++) {
			scanf("%d",&b);
			ll tmp = 0;
			for(int j = 1;j * 2 <= b;j *= 2) {
				v[++cnt] = j * a[i];
				tmp += j;
			}
			if(tmp != b) {
				v[++cnt] = (b - tmp) * a[i];
			}
		}
		f[0] = 1;
		for(int i = 1;i <= cnt;i++) {
			for(int j = m;j >= v[i];j--) {
				if(f[j - v[i]]) f[j] = 1;
			}
		}
		int ans = 0;
		for(int i = 1;i <= m;i++) {
			if(f[i]) ans++;
		}
		printf("%d\n",ans);
	}
	void main() {
		while(true) {
			scanf("%d%d",&n,&m);
			if(n == 0 && m == 0) break;
			work();
		}
	}
};
int main() {
	SXL::main();
	return 0;
}
