#include <bits/stdc++.h>
using namespace std;
int dp[10000];
int main() {
	int n,m;
	scanf("%d%d",&n,&m);
	dp[0] = 1;
	for(int i = 1,a;i <= n;i++) {
		scanf("%d",&a);
		for(int j = m;j >= a;j--) {
			dp[j] += dp[j - a];
		}
	}
	printf("%d",dp[m]);
	return 0;
}
