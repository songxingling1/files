#include <bits/stdc++.h>
namespace SXL {
	using std::vector;
	using std::max;
	constexpr int MAXNM = 1000,MAXK = 100;
	int dp[MAXNM];
	vector<int> a[MAXK];
	vector<int> b[MAXK];
	int n,m;
	void main() {
		scanf("%d%d",&m,&n);
		int ans = 0,maxk = 0;
		for(int i = 1,aa,bb,cc;i <= n;i++) {
			scanf("%d%d%d",&aa,&bb,&cc);
			a[cc].push_back(aa);
			b[cc].push_back(bb);
			maxk = max(maxk,cc);
		}
		int len;
		for(int i = 1;i <= maxk;i++) {
			len = a[i].size();
			for(int j = m;j >= 0;j--) {
				for(int k = 0;k < len;k++) {
					if(a[i][k] <= j) {
						dp[j] = max(dp[j],dp[j - a[i][k]] + b[i][k]);
					}
				}
			}
		}
		printf("%d\n",dp[m]);
	}
}
int main() {
	SXL::main();
	return 0;
}
