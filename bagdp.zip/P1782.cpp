#include <bits/stdc++.h>
#define int long long
namespace SXL {
	using std::vector;
	using std::max;
	constexpr int MAXN = 100000,MAXM = 5;
	vector<int> w[MAXN + MAXM + 5];
	vector<int> v[MAXN + MAXM + 5];
	int dp[10005];
	int tot = 0;
	int clac(int a,int b,int c,int x) {
		return a * x * x + b * x + c;
	}
	void main() {
		int n,m,C;
		scanf("%lld%lld%lld",&n,&m,&C);
		for(int i = 1,a,b,c;i <= n;i++) {
			scanf("%lld%lld%lld",&a,&b,&c);
			for(int j = 1;j <= c;j *= 2) {
				v[++tot].push_back(a * j);
				w[tot].push_back(b * j);
				c -= j;
			}
			if(c) {
				v[++tot].push_back(a * c);
				w[tot].push_back(b * c);
			}
		}
		for(int i = 1,a,b,c;i <= m;i++) {
			scanf("%lld%lld%lld",&a,&b,&c);
			++tot;
			for(int j = 0;j <= C;j++) {
				int tmp = clac(a,b,c,j);
				if(tmp < 0) continue;
				v[tot].push_back(j);
				w[tot].push_back(tmp);
			}
		}
		int len;
		for(int i = 1;i <= tot;i++) {
			len = v[i].size();
			for(int j = C;j >= 0;j--) {
				for(int k = 0;k < len;k++) {
					if(j >= v[i][k]) {
						dp[j] = max(dp[j],dp[j - v[i][k]] + w[i][k]);
					}
				}
			}
		}
		printf("%lld\n",dp[C]);
	}
}
signed main() {
	SXL::main();
	return 0;
}
