#include <bits/stdc++.h>
namespace SXL {
	using ll = long long;
	constexpr int MAXN = 120000;
	int cnt = 0,m;
	int w[MAXN + 5];
	int dp[MAXN];
	int k[6];
	void work() {
		memset(dp,0,sizeof(dp));
		dp[0] = 1;
		for(int i = 1;i <= cnt;i++) {
			for(int j = m;j >= w[i];j--) {
				if(dp[j - w[i]]) {
					dp[j] = 1;
				}
			}
		}
	}
	void main() {
		while(true) {
			cnt = 0;
			scanf("%d%d%d%d%d%d",k,k + 1,k + 2,k + 3,k + 4,k + 5);
			if(k[0] == 0 && k[1] == 0 && k[2] == 0 && k[3] == 0 && k[4] == 0 && k[5] == 0)
				break;
			m = (k[0] + k[1] * 2 + k[2] * 3 + k[3] * 4 + k[4] * 5 + k[5] * 6);
			if(m % 2 == 1) {
				puts("Can't");
				continue;
			} else m /= 2;
			for(int q = 0;q < 6;q++) {
				int c = 1;
				ll tmp = 0;
				while(tmp + c <= k[q]) {
					w[++cnt] = c * q + c;
					tmp += c;
					c *= 2;
				}
				if(tmp != k[q]) {
					w[++cnt] = (q + 1) * (k[q] - tmp);
				}
			}
			work();
			if(dp[m]) puts("Can");
			else puts("Can't");
		}
	}
};
int main() {
	SXL::main();
	return 0;
}
