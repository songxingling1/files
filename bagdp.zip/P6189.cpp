#include <bits/stdc++.h>
namespace SXL {
	constexpr int MAXN = 100000;
	int f[MAXN + 5];
	int g[400][MAXN + 5];
	void main() {
		int n,p;
		scanf("%d%d",&n,&p);
		int m = sqrt(n) + 1;
		f[0] = 1;
		for(int i = 1;i < m;i++) {
			for(int j = i;j <= n;j++) {
				f[j] = (f[j] + f[j - i]) % p;
			}
		}
		g[0][0] = 1;
		for(int i = 1;i < m;i++) {
			for(int j = i;j <= n;j++) {
				g[i][j] = (g[i][j] + g[i][j - i]) % p;
				if(j >= m) g[i][j] = (g[i][j] + g[i - 1][j - m]) % p;
			}
		}
		int ans = 0;
		for(int i = 0;i <= n;i++) {
			long long sum = 0;
			for(int j = 0;j < m;j++) sum += g[j][n - i];
			sum %= p;
			ans = (ans + sum * f[i]) % p;
		}
		printf("%d\n",ans);
	}
}
int main() {
	SXL::main();
	return 0;
}
