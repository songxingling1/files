#include <bits/stdc++.h>
namespace SXL {
	using std::max;
	using std::min;
	using std::swap;
	constexpr int MAXN = 6000,MAXT = 30000;
	int dp[2][MAXT + 5];
	void main() {
		int n;
		scanf("%d",&n);
		int now = 0,last = 1;
		memset(dp[last],0x7f,sizeof(dp[last]));
		dp[last][0] = 0;
		for(int i = 1,a,b,c;i <= n;i++){
			scanf("%d%d%d",&a,&b,&c);
			memset(dp[now],0x7f,sizeof(dp[now]));
			for(int j = 0;j <= MAXT;j++) {
				if(a != 0 && j >= a) {
					dp[now][j] = min(dp[now][j],dp[last][j - a]);
				}
				if(b != 0) {
					dp[now][j] = min(dp[now][j],dp[last][j] + b);
				}
				if(c != 0 && j >= c) {
					dp[now][j] = min(dp[now][j],dp[last][j - c] + c);
				}
			}
			swap(now,last);
		}
		int ans = INT_MAX;
		for(int i = 0;i <= MAXT;i++){
			ans = min(ans,max(i,dp[last][i]));
		}
		printf("%d\n",ans);
	}
}
int main() {
	SXL::main();
	return 0;
}
